<?php
header("Location: read_gudang.php");
exit(); 
?>
